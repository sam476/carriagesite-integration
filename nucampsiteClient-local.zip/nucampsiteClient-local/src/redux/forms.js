export const InitialFeedback = {
    firstName: '',
    lastName: '',
    phoneNum: '',
    email: '',
    agree: false,
    contactType: 'Phone',
    feedback: ''
};